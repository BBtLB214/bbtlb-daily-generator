def generate_underdog_props(projections):
    print('Underdog props generated')
