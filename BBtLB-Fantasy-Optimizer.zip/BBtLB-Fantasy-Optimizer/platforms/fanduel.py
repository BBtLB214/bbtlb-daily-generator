def optimize_fd(projections):
    print('FanDuel lineup optimized')
