def optimize_dk(projections):
    print('DraftKings lineup optimized')
