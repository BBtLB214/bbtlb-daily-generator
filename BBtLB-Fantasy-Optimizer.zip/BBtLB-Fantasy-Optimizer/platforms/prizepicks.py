def generate_prizepicks_props(projections):
    print('PrizePicks props generated')
